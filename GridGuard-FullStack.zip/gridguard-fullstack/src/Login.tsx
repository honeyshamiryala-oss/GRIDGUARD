import { useState, type FormEvent } from 'react';
import { apiRequest } from './api';

interface LoginProps { onLogin: () => void; onRegister: () => void; }
export default function Login({ onLogin, onRegister }: LoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleLogin(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setMessage(''); setLoading(true);
    try {
      const data = await apiRequest('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) });
      localStorage.setItem('gridguardToken', data.token);
      onLogin();
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Login failed'); }
    finally { setLoading(false); }
  }

  return <main className="min-h-screen bg-slate-950 text-white flex items-center justify-center p-5"><section className="w-full max-w-md rounded-2xl border border-slate-700 bg-slate-900 p-8 shadow-2xl shadow-cyan-950/30"><header className="text-center mb-8"><div className="mx-auto mb-3 grid h-14 w-14 place-items-center rounded-2xl bg-cyan-500/15 text-3xl">⚡</div><h1 className="text-4xl font-black tracking-tight">GridGuard</h1><p className="mt-2 text-slate-400">Electrical Grid Monitoring System</p><p className="mt-4 text-xs font-semibold uppercase tracking-widest text-emerald-400">● Control center access</p></header><form onSubmit={handleLogin} className="space-y-4"><label className="block text-sm text-slate-300">Email address<input required type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" className="mt-2 w-full rounded-lg border border-slate-700 bg-slate-800 px-4 py-3 outline-none focus:border-cyan-400" /></label><label className="block text-sm text-slate-300">Password<input required type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Enter password" className="mt-2 w-full rounded-lg border border-slate-700 bg-slate-800 px-4 py-3 outline-none focus:border-cyan-400" /></label>{message && <p role="alert" className="rounded-lg border border-red-800 bg-red-950/60 p-3 text-sm text-red-300">{message}</p>}<button disabled={loading} className="w-full rounded-lg bg-cyan-500 py-3 font-bold text-slate-950 hover:bg-cyan-400 disabled:opacity-60">{loading ? 'Signing in…' : 'Login to GridGuard'}</button></form><p className="mt-6 text-center text-sm text-slate-400">New operator? <button onClick={onRegister} className="font-semibold text-cyan-400 hover:text-cyan-300">Create account</button></p><footer className="mt-8 border-t border-slate-800 pt-5 text-center text-xs text-slate-500">GridGuard © 2026 · Monitoring & diagnostics</footer></section></main>;
}
