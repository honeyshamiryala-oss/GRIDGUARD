import { useState } from 'react';
import App from './App';
import Login from './Login';
import Register from './Register';

export default function Pages() {
  const [page, setPage] = useState<'login' | 'register' | 'home'>(() => getTokenNow() ? 'home' : 'login');
  if (page === 'home') return <App onLogout={() => { localStorage.removeItem('gridguardToken'); setPage('login'); }} />;
  if (page === 'register') return <Register onLogin={() => setPage('login')} />;
  return <Login onLogin={() => setPage('home')} onRegister={() => setPage('register')} />;
}
function getTokenNow() { return localStorage.getItem('gridguardToken'); }
