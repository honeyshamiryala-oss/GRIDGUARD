import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import Pages from './Pages';

createRoot(document.getElementById('root')!).render(
  <React.StrictMode><Pages /></React.StrictMode>
);
