# GridGuard — Electrical Grid Monitoring System

A college PBL full-stack web application. The readings in this version are simulated in the browser; the application stores readings in PostgreSQL for each logged-in user.

## Stack
- Frontend: React, TypeScript, Vite, Tailwind CSS, Recharts
- Backend: Node.js, Express
- Database: PostgreSQL (local or hosted, e.g. Neon)
- Authentication: bcrypt password hashing and JWT bearer tokens

## Requirements
Install Node.js LTS. Have access to a PostgreSQL database. A hosted PostgreSQL database is convenient if PostgreSQL is not installed locally.

## Setup database
1. Create a PostgreSQL database using your provider.
2. Copy `backend/.env.example` to `backend/.env`.
3. Set `DATABASE_URL` to the connection string supplied by your database provider and set `JWT_SECRET` to a long random secret.
4. From a terminal, run:

```powershell
cd backend
npm install
npm run db:init
```

The schema creates `users` and `readings` tables. Do not commit `backend/.env`.

## Run backend
From `gridguard/backend`:

```powershell
npm run dev
```

Health check: open `http://localhost:5000/api/health`. It should report `status: ok` and `database: connected` after database configuration and schema initialization.

## Run frontend
Open a second terminal in the project root (`gridguard`):

```powershell
npm install
npm run dev
```

Open the URL Vite prints, normally `http://localhost:5173`.

## Use
1. Register with a name, email and password of at least 8 characters.
2. Log in with those credentials.
3. The dashboard loads the latest stored readings for that account.
4. Start/Stop toggles automatic simulated readings. Generate & Save Reading inserts one reading into PostgreSQL.
5. Logout returns to login.

## API
- `GET /api/health` — server/database health
- `POST /api/auth/register` — `{ "name", "email", "password" }`
- `POST /api/auth/login` — `{ "email", "password" }`; returns JWT
- `GET /api/auth/me` — authenticated profile
- `GET /api/readings?limit=20` — authenticated user's latest readings
- `POST /api/readings` — authenticated insert `{ "temperature", "voltage", "current" }`

Protected endpoints require `Authorization: Bearer <token>`.

## Testing checklist
- Health endpoint reports database connected.
- Register a new account; verify duplicate email is rejected.
- Log in; wrong password should fail.
- Generate a reading and confirm it appears in the dashboard.
- Refresh the page and confirm stored history is retrieved.
- Stop monitoring and confirm automatic inserts pause; Start to resume.
- Verify 2×2 reading cards and vertically stacked status cards.

## Limitations and future enhancements
- Sensor data is simulated; no physical sensors are connected.
- JWT is stored in localStorage for this educational demo, which is vulnerable to script injection. A production system should use a more robust session strategy, HTTPS, rate limiting, stricter CORS, and security monitoring.
- Future work: connect real sensors or an IoT gateway, add WebSockets for live telemetry, export reports, and add role-based access control.
