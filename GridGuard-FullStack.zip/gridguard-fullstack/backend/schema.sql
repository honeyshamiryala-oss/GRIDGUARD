CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS readings (
  id BIGSERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  temperature NUMERIC(6,2) NOT NULL CHECK (temperature >= 0),
  voltage NUMERIC(6,2) NOT NULL CHECK (voltage >= 0),
  current NUMERIC(6,2) NOT NULL CHECK (current >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS readings_user_created_idx ON readings(user_id, created_at DESC);
