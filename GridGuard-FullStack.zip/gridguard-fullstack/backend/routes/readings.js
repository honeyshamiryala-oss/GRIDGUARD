import { Router } from 'express';
import { pool } from '../db.js';
import { requireAuth } from '../middleware/auth.js';
const router = Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  const limit = Math.min(Math.max(Number.parseInt(req.query.limit, 10) || 20, 1), 100);
  try {
    const result = await pool.query('SELECT id, temperature, voltage, current, created_at FROM readings WHERE user_id = $1 ORDER BY created_at DESC LIMIT $2', [req.user.id, limit]);
    return res.json({ readings: result.rows });
  } catch (error) { console.error(error.message); return res.status(500).json({ message: 'Could not retrieve readings.' }); }
});

router.post('/', async (req, res) => {
  const temperature = Number(req.body.temperature); const voltage = Number(req.body.voltage); const current = Number(req.body.current);
  if (![temperature, voltage, current].every(Number.isFinite) || temperature < 0 || voltage < 0 || current < 0) return res.status(400).json({ message: 'Temperature, voltage, and current must be valid non-negative numbers.' });
  try {
    const result = await pool.query('INSERT INTO readings (user_id, temperature, voltage, current) VALUES ($1, $2, $3, $4) RETURNING id, temperature, voltage, current, created_at', [req.user.id, temperature, voltage, current]);
    return res.status(201).json({ reading: result.rows[0] });
  } catch (error) { console.error(error.message); return res.status(500).json({ message: 'Could not save reading.' }); }
});
export default router;
