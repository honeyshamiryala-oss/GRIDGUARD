import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { pool } from './db.js';
import authRoutes from './routes/auth.js';
import readingRoutes from './routes/readings.js';
dotenv.config();
const app = express();
app.use(cors({ origin: process.env.FRONTEND_URL || 'http://localhost:5173' }));
app.use(express.json({ limit: '100kb' }));
app.get('/api/health', async (_req, res) => {
  try { await pool.query('SELECT 1'); res.json({ status: 'ok', database: 'connected' }); }
  catch (error) { res.status(503).json({ status: 'error', database: 'unavailable', message: 'Check DATABASE_URL and run schema.sql.' }); }
});
app.use('/api/auth', authRoutes);
app.use('/api/readings', readingRoutes);
app.use((err, _req, res, _next) => { console.error(err); res.status(500).json({ message: 'Unexpected server error.' }); });
const port = Number(process.env.PORT || 5000);
app.listen(port, () => console.log(`GridGuard API listening on http://localhost:${port}`));
