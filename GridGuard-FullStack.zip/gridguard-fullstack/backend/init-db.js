import fs from 'node:fs/promises';
import { pool } from './db.js';
try {
  const sql = await fs.readFile(new URL('./schema.sql', import.meta.url), 'utf8');
  await pool.query(sql);
  console.log('GridGuard tables created successfully.');
} catch (error) {
  console.error('Database initialization failed:', error.message);
  process.exitCode = 1;
} finally { await pool.end(); }
